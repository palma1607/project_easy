package com.example.chat_psicotinder.model

data class User(var userId:String = "", var userName:String = "", var profileImage:String = "")